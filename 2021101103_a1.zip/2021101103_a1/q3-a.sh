#!/bin/bash

#Reading the file - 
read

#a
stat --printf="%s\n" $REPLY
